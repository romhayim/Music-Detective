import sqlite3


sqliteConnection = sqlite3.connect('music.db')
cursor = sqliteConnection.cursor()

table = """ CREATE TABLE USER (
            ID INTEGER PRIMARY KEY,
            USERNAME CHAR(25) NOT NULL,
            First_Name CHAR(25),
            Last_Name CHAR(25),
            Password CHAR(25),
            Score INT(5)
        ); """

cursor.execute(table)
cursor.execute(
  '''INSERT INTO USER (USERNAME, First_Name, Last_Name,Password,Score) VALUES ('romhayim', 'Rom Hayim',
  'Hakima','1234',0)''')
print("Table is Ready")

data = cursor.execute('''SELECT * FROM USER''')
for row in data:
    print(row)

# Commit your changes in

# the database
sqliteConnection.commit()

# Closing the connection
sqliteConnection.close()